# Brand and icon assets

- `../brand/mark.svg` is the وَصْل application mark and browser favicon.
- Interface icons are defined as reusable inline SVG symbols in `index.html` so the experience has no icon-library dependency.
